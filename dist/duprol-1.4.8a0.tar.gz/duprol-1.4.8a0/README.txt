This is the PyPI mirror for DPL.

For real bleeding edge versions
check out the git repo instead!

https://github.com/RenrenRihitoRayo/dpl